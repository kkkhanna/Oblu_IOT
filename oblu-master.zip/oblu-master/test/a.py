x=6
print(x)