import a

print(a.x)
a.x=8
print(a.x)